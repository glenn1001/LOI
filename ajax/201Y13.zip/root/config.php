<?php

$dbHost = 'localhost';
$dbUser = 'glennia29_loi';
$dbPass = 'loi';
$dbName = 'glennia29_loi';
?>