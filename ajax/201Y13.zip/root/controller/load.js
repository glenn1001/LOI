function load() {
    loadAccount();
    setTimeout("loadBlog(1)",500);
}